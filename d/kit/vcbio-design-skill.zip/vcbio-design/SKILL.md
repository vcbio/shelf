---
name: vcbio-design
description: 브이씨바이오(VCBio, 건강기능식품 B2B OEM/ODM)의 브랜드 디자인 규격 — 색 프리셋 4종·Pretendard 타이포 스케일·8px 간격 리듬·덱 캔버스 규격·자가검수 체크리스트를 담고 있다. 사용자가 "브이씨바이오 자료", "VCBio 덱", "제안덱", "제안서", "브로셔", "브랜드 규격대로", "우리 브랜드 톤으로", "회사 디자인 가이드 적용해서"라고 하거나, 이 브랜드의 슬라이드·PPT·A4 인쇄물·랜딩 페이지·대시보드·모션클립·SNS 카드를 만들거나 고칠 때 쓴다. 색 HEX·폰트·간격 값을 고르기 전에 반드시 이 스킬을 먼저 연다. Brand design system for VCBio, a Korean B2B nutraceutical (health functional food) OEM/ODM company. Use whenever building or reviewing VCBio-branded visual output — proposal decks, slides, pitch decks, brochures, print A4, landing pages, dashboards, motion clips, social cards — or when the user says "brand guidelines", "our design system", "company style", "on-brand", "VCBio design". Defines four color presets (calm-charcoal, hot-lime, hot-orange, electric-blue), a Pretendard-only type scale, spacing tokens, chart palettes, and a pre-delivery QA checklist.
---

# VCBio 디자인 규격

브이씨바이오(VCBio) — 건강기능식품 B2B OEM/ODM.
색·글자·간격 값은 이 스킬 안의 파일이 정본이다. 임의로 만들지 않는다.

## 톤 한 줄

1970년대 대학 세미나 핸드아웃의 차분함에 현대 바이오테크의 정밀함을 얹은 톤.
대형 식품·제약사에 원료를 제안하는 B2B 문서가 주 무대라 기본 인격은 **차분·신뢰·보수**다.
과장된 색면보다 절제, 장식보다 위계, 근거 중심.

핵심 축은 **딥그린 키컬러 하나 + 곡물톤(크림·베이지) 바탕**이다. 흰색이 아니라 크림을 쓰는 이유는
유기적이고 따뜻한 인상 때문이다.

이건 웹앱 UI 가이드가 아니다. 산출물은 ①16:9 제안덱 ②A4 인쇄 브로셔 ③대시보드 ④세로·가로 모션클립이다.

## 작업 순서

1. **조합 확인** — 사용자가 선택보드에서 복사한 조합 문장(프리셋·HEX·스타일)을 줬는지 먼저 본다.
   줬으면 그게 최우선이고, 이 스킬은 그 조합을 벗어나지 않게 잡아주는 역할만 한다.
   조합이 없으면 아래 프리셋 선택 규칙으로 하나를 고르고, 고른 이유를 한 줄로 밝힌 뒤 진행한다.
   선택보드: https://vcbio.github.io/shelf/d/colorboard.html
2. **규격 적용** — 만들 것에 맞는 참고 파일을 열고 값을 그대로 쓴다(아래 라우팅 표).
   웹·HTML 산출물이면 `assets/vcbio-tokens.css`를 먼저 불러오고 역할 토큰(`--vc-bg`, `--vc-fg`, `--vc-key`)을 쓴다.
3. **자가검수** — 넘기기 전에 `references/checklist.md`를 항목별로 훑는다.
   실제 렌더 결과(PNG·PDF·브라우저 화면)를 눈으로 확인한다. 코드가 통과했다는 것으로 대신하지 않는다.

## 참고 파일 라우팅

| 상황 | 열 파일 |
|---|---|
| HEX를 고를 때, 프리셋을 정할 때, 차트 시리즈 색·회색조가 필요할 때 | `references/colors.md` |
| 제목·본문 크기와 웨이트, 자간·행간을 정할 때 | `references/typography.md` |
| 간격·격자·모서리, 덱 캔버스와 안전여백, 산출물 포맷별 규격이 필요할 때 | `references/layout.md` |
| 산출물을 넘기기 직전 | `references/checklist.md` |
| 표지 헤드라인·강조 문구·eyebrow 같은 문장을 쓸 때 | `references/copy-rules.md` |
| CSS 변수로 바로 쓰고 싶을 때 | `assets/vcbio-tokens.css` |

값이 필요한 순간에 해당 파일을 연다. 기억으로 HEX를 적지 않는다.

## 프리셋 선택 규칙

한 산출물은 프리셋 하나를 키로 잡는다. **섞지 않는다.** 그라디언트 스톱도 고른 프리셋 안에서만 고른다.

| 프리셋 | 성격 | 언제 |
|---|---|---|
| `calm-charcoal` | 차분·신뢰·보수 | 공식 제출·IR·규제 대응 톤 — **기본값** |
| `hot-lime` | 강렬·테크 | 임팩트물·티저·SNS·랜딩 히어로 |
| `hot-orange` | 대담·프리미엄 | 캠페인·표지·발표 임팩트 |
| `electric-blue` | 미래·데이터 | 웹 대시보드·플랫폼·테크 제안 |

판단이 애매하면 `calm-charcoal`이다. 받는 쪽이 외부 기업·기관이면 특히 그렇다.

## 절대 규칙

1. **프리셋 하나만.** 두 프리셋의 색을 한 산출물에 섞지 않는다.
2. **규격 밖 색 창작 금지.** `references/colors.md`에 없는 HEX를 만들지 않는다.
3. **Pretendard 단독.** 영문 고유명사도 Pretendard로 간다. 예외는 모션클립 트랙 하나뿐이고 그 트랙은 GMarket Sans를 쓴다.
4. **5% 룰.** `calm-charcoal`에서 키컬러는 화면의 5% 이하 — 룰선·단어 하나·배지·작은 면.
   표지·디바이더·히어로와 hot 계열 프리셋은 이 제한이 풀려 색면·발광·풀블리드를 대담하게 써도 된다.
   다만 **본문 가독 영역**(데이터·표·긴 텍스트)은 프리셋과 무관하게 키컬러 대면적을 피한다.
5. **본문 대비 4.5:1 이상.** WCAG AA 기준. 자동 통과를 가정하지 말고 실제 조합으로 계산한다.
6. **위계는 크기·웨이트 차이로만.** 한 화면에 크기 위계가 세 단계 이상 보여야 한다.
7. **자간은 caption 대문자에만.** 본문 자간은 건드리지 않는다.
8. **차트 색은 지정 스킴에서.** 즉흥으로 고르지 않는다.
9. **모션은 절제.** 무한반복·글리치·난수 기반 움직임 금지. `prefers-reduced-motion`을 존중한다.
10. **한국어 HTML은 맨 앞에 `<meta charset="UTF-8">`.** 없으면 한글이 깨진다.
11. **없는 수치·없는 시험·없는 인증을 지어내지 않는다.** 수치에는 출처를 붙인다.
12. **이모지 아이콘·출처 불명 클립아트 금지.** 아이콘은 한 세트로 통일한다.

## 넘길 때 함께 줄 것

- 산출물 파일
- 실제 렌더 결과 이미지(장별 또는 표지 1장)
- 쓴 프리셋 이름, 그리고 규격에서 벗어난 항목이 있으면 그 사유
