# 타이포

## 1. 폰트

폰트는 **Pretendard 단독**이다. 제목·본문·데이터·표지 전부 Pretendard를 쓰고,
위계는 **크기와 웨이트 차이로만** 만든다. 지정 없이 다른 서체를 섞지 않는다.
영문 고유명사도 Pretendard로 간다.

예외는 모션클립 트랙 하나뿐이며, 그 트랙은 GMarket Sans를 쓴다.

Pretendard는 Thin(100)부터 Black(900)까지 9웨이트가 있고,
**Thin 거대 글자 + Black 키워드**의 극단 대비가 표지 임팩트를 만든다.

CSS 폰트 스택:

```css
font-family: "Pretendard Variable", Pretendard, -apple-system,
             BlinkMacSystemFont, system-ui, "Apple SD Gothic Neo", sans-serif;
```

웹이면 웹폰트를 실제로 불러오고, 파일로 넘길 산출물이면 폰트를 임베딩하거나 아웃라인 처리한다.
받는 쪽 PC에서 대체 폰트로 깨지면 규격을 지킨 의미가 없다.

## 2. 스케일

| 토큰 | 실사용 값 | 정본 범위(rem / 인쇄 pt) | 웨이트 | 용도 |
|---|---|---|---|---|
| mega | 12.5rem | 10–15rem / 160–240pt | Thin ↔ Black | 표지·디바이더 전용 초대형 |
| hero | 8.125rem | 5.6–8.75rem / 90–140pt | Black·Bold | 디바이더 대형 글리프·거대수치 |
| display | 6rem | 5.0–6.5rem / 80–104pt | Bold | 표지 초대형 타이틀 |
| h1 | 1.9rem | 1.9–2.9rem / 30–46pt | Bold | 슬라이드 제목 |
| h2 | 1.25rem | 1.25–1.5rem / 18–24pt | Bold | 부제목·카드 헤드 |
| body-lg | 1rem | 0.95–1rem / 15–16pt | Regular | 본문 강조 |
| body | 0.875rem | 0.8–0.9rem / 12–14pt | Regular | 본문 |
| caption | 0.6875rem | 0.65–0.7rem / 10–11pt | Bold | eyebrow·출처 |

기준은 1rem = 16px.

## 3. 웨이트 역할

| 웨이트 | 값 | 역할 |
|---|---|---|
| Thin | 100 | 표지 초대형 타이포 |
| Regular | 400 | 본문 |
| Bold | 700 | 제목·강조 |
| Black | 900 | 표지·디바이더 핵심어 |

중간 웨이트(300·500·600)는 위계를 흐린다. 위 네 개로 끝낸다.

## 4. 자간(트래킹)

자간을 **넓히는** 곳은 caption 대문자 하나뿐이다. 본문 자간은 건드리지 않는다.
큰 제목은 커질수록 자간을 좁혀야 한 덩어리로 읽힌다.

| 토큰 | 값 | 대상 |
|---|---|---|
| tracking-mega | -0.045em | mega |
| tracking-display | -0.03em | display·hero |
| tracking-heading | -0.018em | h1·h2 |
| tracking-body | 0 | body·body-lg |
| tracking-caption | 0.16em | caption 대문자 eyebrow 전용 |

한글 eyebrow는 대문자 개념이 없으므로 자간을 과하게 주지 않는다(영문 대문자의 절반 수준).

## 5. 행간(리딩)

큰 글자일수록 좁게, 본문일수록 넉넉하게 간다.

| 토큰 | 값 | 대상 |
|---|---|---|
| leading-tight | 1.02 | mega·hero·display |
| leading-snug | 1.24 | h1·h2 |
| leading-normal | 1.5 | 짧은 문단·캡션 묶음 |
| leading-body | 1.7 | 본문 |

## 6. 위계 만들기

- 한 화면에 크기 위계가 **세 단계 이상** 보이게 한다(예: display / h2 / body).
- 크기 차이가 애매하면 위계가 아니라 실수로 보인다. 인접 단계는 최소 1.4배 이상 벌린다.
- 표지는 큰 글자와 작은 글자의 강한 대비가 있어야 한다 — mega/hero 옆에 caption을 붙이는 식.
- 글자가 상자 밖으로 잘리거나 말줄임으로 먹힌 곳이 없는지 렌더로 확인한다.
- 번호나 짧은 라벨이 두 줄로 쪼개지지 않게 한다(예: 01이 0과 1로 나뉘는 경우).
