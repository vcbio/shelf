# VCBio 디자인 규격 — AI 도구 설치 킷

브이씨바이오(VCBio)의 브랜드 디자인 규격을 **AI 도구가 스스로 읽고 따르도록** 묶은 패키지입니다.
색 HEX·폰트·간격·검수 기준이 들어 있어, 설치해 두면 매번 규격을 붙여넣지 않아도 됩니다.

## 3단계로 끝내기

### 1단계 — 압축 풀기

`vcbio-design-skill.zip`을 풀면 이 구조가 나옵니다.

```
vcbio-design/            ← 스킬 본체
  SKILL.md               작업 순서 · 프리셋 선택 규칙 · 절대 규칙
  references/
    colors.md            프리셋 4종 전체 HEX · 차트 스킴 · 회색조 12스텝
    typography.md        Pretendard 스케일 · 웨이트 · 자간 · 행간
    layout.md            간격 · 격자 · 캔버스 · 모션 · 산출물 포맷
    checklist.md         출고 전 자가검수
    copy-rules.md        카피 톤 · 금지 표현
  assets/
    vcbio-tokens.css     CSS 변수
AGENTS.md                Codex · opencode 등 에이전트용
CLAUDE.md                Claude Code 프로젝트 메모리용
.cursor/rules/vcbio-design.mdc   Cursor용
README.md                이 파일
```

`vcbio-design.skill`은 스킬 폴더만 담은 업로드용 파일입니다(2단계 표 참고).

### 2단계 — 쓰는 도구에 맞게 넣기

| 도구 | 어디에 넣나 | 방법 |
|---|---|---|
| **Claude Code** | `~/.claude/skills/vcbio-design/` (전역) 또는 프로젝트의 `.claude/skills/vcbio-design/` | `vcbio-design` 폴더를 통째로 복사합니다. 프로젝트 전용으로 쓸 거면 `CLAUDE.md`도 프로젝트 루트에 함께 둡니다. |
| **Claude 앱 (웹·데스크톱)** | 설정 → 기능(Capabilities) → 스킬 | `vcbio-design.skill` 파일을 업로드합니다. |
| **Cursor** | 프로젝트 루트의 `.cursor/rules/` | `.cursor/rules/vcbio-design.mdc`를 복사합니다. 폴더가 없으면 만듭니다. 토큰 파일도 쓰려면 `vcbio-design/assets/vcbio-tokens.css`를 프로젝트 안에 함께 둡니다. |
| **Codex · opencode · 그 밖의 에이전트 CLI** | 프로젝트 루트 | `AGENTS.md`를 프로젝트 루트에 둡니다. `vcbio-design` 폴더도 같은 위치에 두면 에이전트가 참고 파일까지 열어 봅니다. |
| **ChatGPT · Gemini · 그 외 채팅형 도구** | 대화창 | `vcbio-design/SKILL.md` 전문을 프롬프트에 붙여넣거나 파일로 첨부합니다. 색·글자 값이 많이 필요한 작업이면 `references/colors.md`와 `typography.md`도 함께 첨부합니다. |
| **웹·HTML 작업 전반** | 프로젝트 안 아무 곳 | `vcbio-design/assets/vcbio-tokens.css`를 불러오고 `data-preset`으로 프리셋을 지정합니다. |

같은 규격이라 여러 도구에 동시에 넣어도 충돌하지 않습니다.

### 3단계 — 작동 확인

도구에 이렇게 물어봅니다.

> 브이씨바이오 브랜드 규격에서 기본 프리셋 이름과 키컬러 HEX가 뭐야?

**calm-charcoal**과 **#1E3932**가 나오면 제대로 인식된 겁니다.
못 찾으면 파일 위치를 다시 확인하고, 채팅형 도구라면 `SKILL.md`를 첨부했는지 봅니다.

## 쓸 때

- 한 산출물에는 프리셋 **하나만** 씁니다. 섞지 않습니다.
- 조합을 눈으로 고르려면 선택보드를 엽니다: https://vcbio.github.io/shelf/d/colorboard.html
  보드에서 복사한 조합 문장을 AI에게 그대로 주면 그 조합이 최우선으로 적용됩니다.
- 넘기기 전에 `vcbio-design/references/checklist.md`를 한 번 훑습니다.

## 값이 바뀌면

이 패키지 안의 파일이 규격의 사본입니다. 회사에서 규격을 갱신하면 새 킷을 받아
같은 위치에 덮어씁니다. 개별 파일을 손으로 고치면 도구마다 값이 어긋납니다.
