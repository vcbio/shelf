# VCBio 디자인 규격 (Claude Code 프로젝트 메모리)

브이씨바이오(VCBio) — 건강기능식품 B2B OEM/ODM.
이 프로젝트에서 **눈에 보이는 산출물**(슬라이드·덱·브로셔·랜딩·대시보드·이미지·모션)을
만들거나 고칠 때는 아래 규격을 지킨다. 색·글자·간격 값은 임의로 만들지 않는다.

## 스킬을 먼저 쓴다

`vcbio-design` 스킬이 설치돼 있으면 그 스킬이 정본이다.
디자인 작업을 시작할 때 `vcbio-design/SKILL.md`를 열고, 값이 필요한 순간에 참고 파일을 연다.

| 필요한 것 | 열 파일 |
|---|---|
| HEX·프리셋·차트 색·회색조 | `vcbio-design/references/colors.md` |
| 글자 크기·웨이트·자간·행간 | `vcbio-design/references/typography.md` |
| 간격·격자·캔버스·모션·포맷 | `vcbio-design/references/layout.md` |
| 출고 직전 검수 | `vcbio-design/references/checklist.md` |
| 헤드라인·카피 문장 | `vcbio-design/references/copy-rules.md` |
| CSS 변수 | `vcbio-design/assets/vcbio-tokens.css` |

기억으로 HEX를 적지 않는다. 매번 파일에서 확인한다.

## 요약 — 이것만은

**색.** 한 산출물에 프리셋 하나만. 섞지 않는다.

| 프리셋 | 언제 | 핵심 HEX |
|---|---|---|
| calm-charcoal (기본값) | 공식 제출·IR·규제 대응 | key #1E3932 · accent #2E7D5B · gold #B8954A · 배경 #F2F0EB · 다크 #1C1C1A |
| hot-lime | 임팩트·티저·SNS·랜딩 히어로 | bg #0A0A0A · key #C6FF2E · text #FFFFFF · sub #8C8C8C |
| hot-orange | 캠페인·표지·발표 임팩트 | bg #15100C · key #FF6A2C · gold #FFB14D · text #FFF1E6 |
| electric-blue | 대시보드·플랫폼·테크 제안 | bg #101720 · key #227AFF · accent #2563EB · tint #BFDAF7 |

증감 색(공통): 상승 #3DDC84 · 하락 #E5484D — 칩은 작게.
**5% 룰** — calm-charcoal에서 키컬러는 화면 5% 이하. 표지·디바이더·히어로와 hot 계열은 풀리지만,
데이터·표·긴 텍스트 영역은 언제나 예외다.

**글자.** Pretendard 단독(영문 고유명사 포함, 모션클립 트랙만 GMarket Sans).
mega 12.5rem(Thin) · hero 8.125rem(Black) · display 6rem(Bold) · h1 1.9rem · h2 1.25rem
· body-lg 1rem · body 0.875rem · caption 0.6875rem(Bold, 대문자 자간).
위계는 크기·웨이트 차이로만, 한 화면 세 단계 이상. 자간을 넓히는 곳은 caption 대문자뿐.

**간격.** 8px 리듬 — 8 / 16 / 24 / 40, 카드 사이 24, 안전여백 64, 12컬럼,
카드 모서리 10px(대형 14px), 배지 999px. 16:9 덱은 1280×720px.

**차트.** 시리즈 하나면 키컬러, 둘 이상이면
#66c2a5 · #fc8d62 · #8da0cb · #e78ac3 · #a6d854 · #ffd92f · #e5c494 · #b3b3b3 를 앞에서부터.

**금지.** 프리셋 혼합 · 규격 밖 색 창작 · 다른 폰트 혼용 · 본문 자간 넓히기 ·
원색 풀블리드 사진(듀오톤 + 하단 다크 그라디언트 필수) · 저해상도 업스케일 ·
차트 색 즉흥 선택 · 이모지 아이콘 · 무한반복·글리치·난수 모션 · 본문 대비 4.5:1 미만 ·
없는 수치·시험·인증 지어내기 · 질병 치료·예방·완치 단정 · "100%·완벽·유일·최고" 류 절대 표현 ·
한국어 HTML의 `<meta charset="UTF-8">` 누락.

## HTML로 만들 때

```html
<html lang="ko" data-preset="calm-charcoal">
<meta charset="UTF-8">
<link rel="stylesheet" href="vcbio-design/assets/vcbio-tokens.css">
```

원색 토큰(`--vc-deep-green`)보다 역할 토큰(`--vc-bg`·`--vc-fg`·`--vc-key`)을 우선한다.
크림 바탕 구역에는 `data-surface="light"`를 준다.

## 마감

코드가 통과했다는 것으로 완료를 대신하지 않는다.
실제 렌더 결과(PNG·PDF·브라우저 화면)를 확인하고,
쓴 프리셋 이름과 규격에서 벗어난 항목이 있으면 그 사유를 함께 보고한다.

조합 선택보드: https://vcbio.github.io/shelf/d/colorboard.html
사용자가 보드에서 복사한 조합 문장을 주면 그게 최우선이다.
